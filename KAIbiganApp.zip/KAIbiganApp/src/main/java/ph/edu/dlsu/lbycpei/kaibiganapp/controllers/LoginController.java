package ph.edu.dlsu.lbycpei.kaibiganapp.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginController {

    @FXML
    private TextField username;

    @FXML
    private TextField password;

    private Label errorLabel;

    private final String FILE_PATH = "data.txt";


    @FXML
    public void viewToAccountName (ActionEvent event) throws IOException {
//        FXMLLoader load = new FXMLLoader(getClass().getResource("/ph/edu/dlsu/lbycpei/kaibiganapp/accountname.fxml"));
//        Parent root = load.load();
//
//        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//        stage.setScene(new Scene(root));
//        stage.show();

        String enteredEmail = username.getText().trim();
        String enteredPassword = password.getText().trim();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) lines.add(line);
            }

            for (int i = 0; i <= lines.size() - 5; i += 5) {

                String setfirstName = lines.get(i);
                String setmiddleName = lines.get(i + 1);
                String setlastName = lines.get(i + 2);
                String setbirthDate = lines.get(i + 3);
                String setheight = lines.get(i + 4);
                String setweight = lines.get(i + 5);
                String setemail = lines.get(i + 6);
                String setpassword = lines.get(i + 7);
                String sethealthCondition = lines.get(i + 8);
                String setmedication = lines.get(i + 9);
                String setworkout = lines.get(i + 10);
                String setworkoutFrequency = lines.get(i + 11);
                String setworkoutType = lines.get(i + 12);


                if (setemail.equals(enteredEmail) && setpassword.equals(enteredPassword)) {
                    loadProfileScene(setfirstName, setmiddleName, setlastName, setbirthDate, setheight, setweight, setemail, setpassword, sethealthCondition, setmedication, setworkout, setworkoutFrequency, setworkoutType);
                    return;
                }
            }

            errorLabel.setText("Invalid email or password.");
        } catch (IOException e) {
            errorLabel.setText("Error reading file.");
            e.printStackTrace();
        }
    }

    @FXML
    public void viewToCreateAccount (ActionEvent event) throws IOException {
        FXMLLoader load = new FXMLLoader(getClass().getResource("/ph/edu/dlsu/lbycpei/kaibiganapp/createaccount.fxml"));
        Parent root = load.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    private void loadProfileScene(String firstName, String middleName, String lastName, String birthDate, String height, String weight, String email, String password, String healthCondition, String medication, String workout, String workoutFrequency, String workoutType) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Profile.fxml"));
            Parent root = loader.load();

            // Get controller and pass data
            PersonalInfoController controller = loader.getController();
            controller.setUserData(firstName, middleName, lastName, birthDate, height, weight, email, password, healthCondition, medication, workout, workoutFrequency, workoutType);

            Stage stage = (Stage) username.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Failed to load profile.");
        }
    }

}

