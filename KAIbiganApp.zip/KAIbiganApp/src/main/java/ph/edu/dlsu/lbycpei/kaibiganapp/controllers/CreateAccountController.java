package ph.edu.dlsu.lbycpei.kaibiganapp.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CreateAccountController {

    @FXML
    private TextField firstName;

    @FXML
    private TextField middleName;

    @FXML
    private TextField lastName;

    @FXML
    private TextField birthDate;

    @FXML
    private TextField height;

    @FXML
    private TextField weight;

    @FXML
    private TextField email;

    @FXML
    private TextField password;

    @FXML
    private TextField healthCondition;

    @FXML
    private TextField medication;

    @FXML
    private TextField workout;

    @FXML
    private TextField workoutFrequency;

    @FXML
    private TextField workoutType;

    private final String FILE_PATH = "data.txt";


    @FXML
    public void viewToAccountName (ActionEvent event) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            writer.write(firstName.getText());
            writer.newLine();
            writer.write(middleName.getText());
            writer.newLine();
            writer.write(lastName.getText());
            writer.newLine();
            writer.write(birthDate.getText());
            writer.newLine();
            writer.write(height.getText());
            writer.newLine();
            writer.write(weight.getText());
            writer.newLine();
            writer.write(email.getText());
            writer.newLine();
            writer.write(password.getText());
            writer.newLine();
            writer.write(healthCondition.getText());
            writer.newLine();
            writer.write(medication.getText());
            writer.newLine();
            writer.write(workout.getText());
            writer.newLine();
            writer.write(workoutFrequency.getText());
            writer.newLine();
            writer.write(workoutType.getText());


        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            Parent root = FXMLLoader.load(getClass().getResource("SceneB.fxml"));
            Stage stage = (Stage) firstName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
